#include "std_lib_facilities.h"

using namespace std;

int main()
{
    cout << "DATE OF BIRTH\n" << endl;
    int date= 1997;
    int year=2019;
    cout<< "Decimal\t hex\t octal "<<endl;
    cout<<date<<"\t"<<hex<<date<<"\t"<<oct<<date<<"  my age: "<<dec<<year-date<<endl;
    return 0;
}
