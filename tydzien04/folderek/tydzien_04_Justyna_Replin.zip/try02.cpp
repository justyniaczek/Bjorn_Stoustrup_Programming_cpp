#include <iostream>

using namespace std;

int main()
{
    int a;
    int b;
     int c;
     int d;
     cin>> a>> hex>> b>>oct >>c>>d;

    cout << a<<" \t"<< b<<"\t "<< c<<" \t"<< d<<endl;
    cout<< " Program wyswietla wyniki w formie decymalnej, niezaleznie od formy w jakiej wprowadzilismy dane";
    return 0;
}
